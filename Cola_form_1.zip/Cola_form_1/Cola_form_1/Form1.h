#pragma once
#include "C1Form.h"

namespace Cola_form_1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;


	C1Form objeto;
	int p=0;

	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtent;
	protected: 
	private: System::Windows::Forms::TextBox^  txtsal;
	private: System::Windows::Forms::Button^  btnent;

	private: System::Windows::Forms::DataGridView^  grilla_cola;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btnsal;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtent = (gcnew System::Windows::Forms::TextBox());
			this->txtsal = (gcnew System::Windows::Forms::TextBox());
			this->btnent = (gcnew System::Windows::Forms::Button());
			this->grilla_cola = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnsal = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_cola))->BeginInit();
			this->SuspendLayout();
			// 
			// txtent
			// 
			this->txtent->Location = System::Drawing::Point(128, 46);
			this->txtent->Name = L"txtent";
			this->txtent->Size = System::Drawing::Size(100, 20);
			this->txtent->TabIndex = 0;
			// 
			// txtsal
			// 
			this->txtsal->Location = System::Drawing::Point(128, 82);
			this->txtsal->Name = L"txtsal";
			this->txtsal->Size = System::Drawing::Size(100, 20);
			this->txtsal->TabIndex = 1;
			// 
			// btnent
			// 
			this->btnent->Location = System::Drawing::Point(31, 42);
			this->btnent->Name = L"btnent";
			this->btnent->Size = System::Drawing::Size(75, 23);
			this->btnent->TabIndex = 2;
			this->btnent->Text = L"Entrada";
			this->btnent->UseVisualStyleBackColor = true;
			this->btnent->Click += gcnew System::EventHandler(this, &Form1::btnent_Click);
			// 
			// grilla_cola
			// 
			this->grilla_cola->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_cola->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla_cola->Location = System::Drawing::Point(57, 127);
			this->grilla_cola->Name = L"grilla_cola";
			this->grilla_cola->Size = System::Drawing::Size(123, 128);
			this->grilla_cola->TabIndex = 4;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Cola";
			this->Column1->Name = L"Column1";
			// 
			// btnsal
			// 
			this->btnsal->Location = System::Drawing::Point(31, 82);
			this->btnsal->Name = L"btnsal";
			this->btnsal->Size = System::Drawing::Size(74, 19);
			this->btnsal->TabIndex = 5;
			this->btnsal->Text = L"Salida";
			this->btnsal->UseVisualStyleBackColor = true;
			this->btnsal->Click += gcnew System::EventHandler(this, &Form1::btnsal_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnsal);
			this->Controls->Add(this->grilla_cola);
			this->Controls->Add(this->btnent);
			this->Controls->Add(this->txtsal);
			this->Controls->Add(this->txtent);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_cola))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnent_Click(System::Object^  sender, System::EventArgs^  e) {

				 grilla_cola->RowCount=m;
				 int elem=System::Convert::ToInt32(txtent->Text);
				if(objeto.empty())
				{objeto.inicio(elem);}
				else
				{objeto.final(elem);
				}
				grilla_cola->Rows[p++]->Cells[0]->Value=System::Convert::ToInt32(elem);

			 }
private: System::Void btnsal_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(objeto.empty()==true)
			 {MessageBox::Show("Cola Vacia");
			 }
			 else{
			 txtsal->Text=System::Convert::ToString(objeto.salida());
			 grilla_cola->Rows->RemoveAt(0);
			 objeto.organizar(--p);
			 for(int i=0;i<p;i++)
			 {grilla_cola->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(objeto.enviar(i));
			 }}
			 


		 }
};
}

