#pragma once
#include <iostream>

#define m 10

using namespace std;

class C1Form
{

private:
	int nodo[m];
	int first;
	int last;
	
public:
	C1Form(void);
	virtual ~C1Form(void);
	bool empty();
	bool full();
	void final(int &elem);
	void inicio(int &elem);
	int salida();
	void organizar(int p);
	int enviar(int i);

};

