#include "StdAfx.h"
#include "C1Form.h"


C1Form::C1Form(void)
{first=0; last=0;
}


C1Form::~C1Form(void)
{
}
bool C1Form::empty()
{if(last==first)
{return true;}
else
{return false;}
}
bool C1Form::full()
{if(last==m-1){return true;}
else{return false;}
}
void C1Form::inicio(int &elem)
{nodo[first]=elem;last++;
}
void C1Form::final(int &elem)
{	if(!full())
	{nodo[last++]=elem;
	}
}
int C1Form::salida()
{last--;
	return nodo[first];
}
void C1Form::organizar(int p)
{for(int i=0;i<=p;i++)
{nodo[i]=nodo[i+1];
}
}
int C1Form::enviar(int i)
{return nodo[i];
}