
//clase Nodo 


#pragma once 
#include "Dato.h"
class Nodo { 
private:
	  Dato dato; //objeto de la clase dto
    Nodo *puntero; //objeto de la clase nodo
     
public: 
  
    Nodo(){ //Constructor de la clase
        puntero = NULL; 
    }
}; 